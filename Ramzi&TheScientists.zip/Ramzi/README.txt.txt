Le jeu est � lancer depuis une machine virtuelle Java,
avec comme configuration "game.WindowGame" en classe principale,
et "-Djava.library.path=lib/natives" en VM arguments.
Si ce n'est pas automatique, les trois fichiers ".jar" pr�sents dans
le dossier "lib" sont � rajouter dans les librairies actives.