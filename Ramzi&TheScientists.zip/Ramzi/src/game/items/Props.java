package game.items;

public class Props {
	public String name;
	public String type;
	public int damage;
	public String src, description;
	public int cooldown;
	public int currentCooldown;
	public Props(){}
}
